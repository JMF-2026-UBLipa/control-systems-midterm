package com.example.bpmonitor

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import com.google.firebase.database.*
import java.util.*

class EmergencyAudioService : Service(), TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private val CHANNEL_ID = "emergency_listener_channel"
    private val NOTIFICATION_ID = 2
    private var database: DatabaseReference? = null
    private var alertListener: ValueEventListener? = null
    private var currentNumber: String? = null

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val number = intent?.getStringExtra("PHONE_NUMBER")
        android.util.Log.d("BPMonitor", "Service onStartCommand - Number: $number")
        
        // Keep the database connection alive even in background
        FirebaseDatabase.getInstance("https://bp-monitor-bc8a2-default-rtdb.asia-southeast1.firebasedatabase.app/").goOnline()

        // Start Foreground immediately to avoid crash on Android 8+
        val notification = createServiceNotification("BP Monitor Active", "Listening for emergency alerts...")
        startForeground(NOTIFICATION_ID, notification)

        if (number != null && number != currentNumber) {
            startListening(number)
        }
        
        return START_STICKY
    }

    private fun createServiceNotification(title: String, content: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(content)
            .setSmallIcon(android.R.drawable.ic_lock_idle_low_battery)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun cleanNumber(raw: String): String {
        // Normalize: remove all non-digits
        var clean = raw.replace(Regex("[^0-9]"), "")
        // If it starts with 0, replace with 63
        if (clean.startsWith("0")) {
            clean = "63" + clean.substring(1)
        }
        return clean.trim()
    }

    private fun startListening(phoneNumber: String) {
        val cleanNumber = cleanNumber(phoneNumber)
        android.util.Log.d("BPMonitor", "Service starting listener for $cleanNumber")
        
        // Use the global URL found in MainActivity for reliability
        val dbUrl = "https://bp-monitor-bc8a2-default-rtdb.asia-southeast1.firebasedatabase.app/"

        // Remove old listener
        currentNumber?.let { oldNum ->
            alertListener?.let { listener ->
                FirebaseDatabase.getInstance(dbUrl).reference.child("alerts").child(oldNum).removeEventListener(listener)
            }
        }

        currentNumber = cleanNumber
        try {
            FirebaseDatabase.getInstance(dbUrl).goOnline()
            database = FirebaseDatabase.getInstance(dbUrl).reference
            
            alertListener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val alertMsg = snapshot.getValue(String::class.java)
                    android.util.Log.d("BPMonitor", "Service Data Change for $cleanNumber: $alertMsg")
                    if (!alertMsg.isNullOrBlank()) {
                        speakAndNotify(alertMsg)
                        // Clear alert
                        database?.child("alerts")?.child(cleanNumber)?.removeValue()
                    }
                }
                override fun onCancelled(error: DatabaseError) {
                    android.util.Log.e("BPMonitor", "Service Listen Error: ${error.message}")
                }
            }

            database?.child("alerts")?.child(cleanNumber)?.addValueEventListener(alertListener!!)
            android.util.Log.d("BPMonitor", "Service listener ATTACHED to alerts/$cleanNumber")
        } catch (e: Exception) {
            android.util.Log.e("BPMonitor", "Service Firebase Init Fail: ${e.message}")
        }
    }

    private fun speakAndNotify(message: String) {
        android.util.Log.d("BPMonitor", "Service: speakAndNotify called with: $message")
        
        // 1. Force Speaker and Max Volume
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioManager.mode = AudioManager.MODE_NORMAL
        @Suppress("DEPRECATION")
        audioManager.isSpeakerphoneOn = true
        val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, maxVol, 0)

        // 2. Speak with high priority - Repeat 3 times (reduced from 10 to not be too annoying)
        val params = Bundle()
        params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
        
        // Split message if it contains a sender number (the | separator)
        val mainMessage = message.split("|").first().trim()
        val fullMsg = "Emergency Alert for Jhune: $mainMessage"
        
        // First one flushes everything else
        tts?.speak(fullMsg, TextToSpeech.QUEUE_FLUSH, params, "EmergencyMsg_0")
        
        // Add 2 more to the queue
        for (i in 1 until 3) {
            tts?.speak(fullMsg, TextToSpeech.QUEUE_ADD, params, "EmergencyMsg_$i")
        }

        // 2. High Priority Notification
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val alertChannelId = "high_priority_alerts"
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(alertChannelId, "Emergency Alerts", NotificationManager.IMPORTANCE_HIGH)
            notificationManager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(this, alertChannelId)
            .setContentTitle("EMERGENCY ALERT")
            .setContentText(mainMessage) // Show the clean message in notification
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setDefaults(Notification.DEFAULT_ALL)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(System.currentTimeMillis().toInt(), notification)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Background Listener", NotificationManager.IMPORTANCE_LOW)
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
            android.util.Log.d("BPMonitor", "Service TTS Initialized Successfully")
            // Test speech to confirm it works on startup
            tts?.speak("BP Monitor background listener is active", TextToSpeech.QUEUE_FLUSH, null, "InitTest")
        } else {
            android.util.Log.e("BPMonitor", "Service TTS Initialization Failed with status: $status")
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        currentNumber?.let {
            database?.child("alerts")?.child(it)?.removeEventListener(alertListener!!)
        }
        super.onDestroy()
    }
}
