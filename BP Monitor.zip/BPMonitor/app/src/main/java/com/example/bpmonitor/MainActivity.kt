package com.example.bpmonitor

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.telephony.SmsManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.ai.client.generativeai.GenerativeModel
import com.google.firebase.database.*
import kotlinx.coroutines.launch
import okhttp3.*
import java.io.IOException
import java.util.Base64
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.random.Random

import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    companion object {
        const val DB_URL = "https://bp-monitor-bc8a2-default-rtdb.asia-southeast1.firebasedatabase.app/"
        const val AI_MODEL = "gemini-1.5-flash"
    }

    private var tts: TextToSpeech? = null
    private val PERMISSION_REQUEST_CODE = 101
    private val CHANNEL_ID = "bp_monitor_alerts"
    
    // 1. AI SETUP
    private val API_KEY = "AIzaSyCdoskgPgjBB_XVj6iYxurDmEmx767nzjw"
    private lateinit var generativeModel: GenerativeModel

    private var emergencyMessage = ""
    private lateinit var database: DatabaseReference
    private var currentListeningNumber: String? = null
    private lateinit var cameraExecutor: ExecutorService
    private var isScanning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // INITIALIZE FIREBASE EXPLICITLY
        try {
            database = FirebaseDatabase.getInstance(DB_URL).reference
        } catch (e: Exception) {
            android.util.Log.e("BPMonitor", "Firebase Init Error: ${e.message}")
            Toast.makeText(this, "Firebase Configuration Error!", Toast.LENGTH_LONG).show()
        }

        createNotificationChannel()
        requestPermissions()

        tts = TextToSpeech(this, this)

        checkFirebaseConnection()

        generativeModel = GenerativeModel(
            modelName = AI_MODEL,
            apiKey = API_KEY
        )

        val bpText = findViewById<TextView>(R.id.bpText)
        val statusText = findViewById<TextView>(R.id.statusText)
        val aiInsightText = findViewById<TextView>(R.id.aiInsightText)
        val simulateButton = findViewById<Button>(R.id.simulateButton)
        val contactInput = findViewById<EditText>(R.id.contactInput)
        val ownNumberInput = findViewById<EditText>(R.id.ownNumberInput)
        val registerButton = findViewById<Button>(R.id.registerButton)
        val stopServiceButton = findViewById<Button>(R.id.stopServiceButton)
        val testConnectionButton = findViewById<Button>(R.id.testConnectionButton)
        val speakTestButton = findViewById<Button>(R.id.speakTestButton)

        // Pre-fill with the emergency contacts you provided
        contactInput.setText("09910476077")

        speakTestButton.setOnClickListener {
            tts?.speak("Voice test success! I can speak perfectly.", TextToSpeech.QUEUE_FLUSH, null, "TestID")
            Toast.makeText(this, "Playing voice test...", Toast.LENGTH_SHORT).show()
        }

        testConnectionButton.setOnClickListener {
            val ownNumber = ownNumberInput.text.toString().trim()
            if (ownNumber.isBlank()) {
                Toast.makeText(this, "Enter your number first!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val clean = cleanNumber(ownNumber)
            
            // Force Online for Test
            FirebaseDatabase.getInstance(DB_URL).goOnline()
            
            database.child("alerts").child(clean).setValue("Connection Test Success!")
                .addOnSuccessListener { 
                    Toast.makeText(this, "CLOUD TEST SENT!", Toast.LENGTH_SHORT).show() 
                    android.util.Log.d("BPMonitor", "Cloud test success for $clean")
                }
                .addOnFailureListener { 
                    Toast.makeText(this, "CLOUD TEST FAILED: ${it.message}", Toast.LENGTH_LONG).show() 
                    android.util.Log.e("BPMonitor", "Cloud test fail: ${it.message}")
                }
        }

        // Load saved own number and start listening automatically
        val sharedPrefs = getSharedPreferences("BPMonitorPrefs", Context.MODE_PRIVATE)
        val savedNumber = sharedPrefs.getString("own_number", "")
        if (!savedNumber.isNullOrBlank()) {
            val clean = cleanNumber(savedNumber)
            ownNumberInput.setText(clean)
            startAlertService(clean)
            startReadingListener(clean) // Start listening for RPi data
        }

        registerButton.setOnClickListener {
            val ownNumber = ownNumberInput.text.toString().trim()
            if (ownNumber.isNotBlank()) {
                val clean = cleanNumber(ownNumber)
                sharedPrefs.edit().putString("own_number", clean).apply()
                startAlertService(clean)
                startReadingListener(clean) // Start listening for RPi data
                Toast.makeText(this, "Service Started for: $clean", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Please enter your number first", Toast.LENGTH_SHORT).show()
            }
        }

        stopServiceButton.setOnClickListener {
            stopService(Intent(this, EmergencyAudioService::class.java))
            stopReadingListener() // Stop listening
            Toast.makeText(this, "Listener Stopped", Toast.LENGTH_SHORT).show()
        }

        simulateButton.setOnClickListener {
            val systolic = Random.nextInt(80, 181)
            val diastolic = Random.nextInt(50, 121)
            val pulse = Random.nextInt(60, 101)
            
            // For testing: Also write to Firebase so you can see it update!
            val myNumber = sharedPrefs.getString("own_number", "") ?: ""
            if (myNumber.isNotBlank()) {
                val clean = cleanNumber(myNumber)
                database.child("latest_reading").child(clean).setValue(mapOf(
                    "systolic" to systolic,
                    "diastolic" to diastolic,
                    "pulse" to pulse
                ))
            }
            
            handleNewReading(systolic, diastolic, pulse)
        }

        cameraExecutor = Executors.newSingleThreadExecutor()
        val scanButton = findViewById<Button>(R.id.scanButton)
        val viewFinder = findViewById<PreviewView>(R.id.viewFinder)

        scanButton.setOnClickListener {
            if (isScanning) {
                stopCamera()
                scanButton.text = "Start Camera Scanner"
                viewFinder.visibility = android.view.View.GONE
            } else {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    startCamera()
                    scanButton.text = "Stop Scanner"
                    viewFinder.visibility = android.view.View.VISIBLE
                } else {
                    ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), PERMISSION_REQUEST_CODE)
                }
            }
            isScanning = !isScanning
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        val viewFinder = findViewById<PreviewView>(R.id.viewFinder)

        cameraProviderFuture.addListener({
            val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(viewFinder.surfaceProvider)
            }

            val imageAnalyzer = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also {
                    it.setAnalyzer(cameraExecutor) { imageProxy ->
                        processImageProxy(imageProxy)
                    }
                }

            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageAnalyzer)
            } catch (e: Exception) {
                android.util.Log.e("BPMonitor", "Use case binding failed", e)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun stopCamera() {
        ProcessCameraProvider.getInstance(this).get().unbindAll()
    }

    @androidx.annotation.OptIn(androidx.camera.core.ExperimentalGetImage::class)
    private fun processImageProxy(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage != null) {
            val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    extractBPFromText(visionText.text)
                }
                .addOnCompleteListener {
                    imageProxy.close()
                }
        } else {
            imageProxy.close()
        }
    }

    private fun extractBPFromText(text: String) {
        android.util.Log.d("BPMonitor", "Scanner detected: $text")
        
        // 1. First, look for the "Slash" format (e.g., 120/80)
        // This is the most reliable way to find BP.
        val slashPattern = Regex("(\\d{2,3})\\s*/\\s*(\\d{2,3})")
        val slashMatch = slashPattern.find(text)
        
        if (slashMatch != null) {
            val sys = slashMatch.groupValues[1].toInt()
            val dia = slashMatch.groupValues[2].toInt()
            processReadingIfValid(sys, dia, 0)
            return
        }

        // 2. If no slash, look for all numbers in the order they appear (Top to Bottom)
        // We filter for numbers between 40 and 220 to ignore dates or tiny icons.
        val pattern = Regex("\\b\\d{2,3}\\b")
        val allNumbers = pattern.findAll(text)
            .map { it.value.toInt() }
            .filter { it in 40..230 }
            .toList()

        // Most BP monitors show:
        // [0] Systolic (Top)
        // [1] Diastolic (Middle)
        // [2] Pulse (Bottom)
        if (allNumbers.size >= 3) {
            val sys = allNumbers[0]
            val dia = allNumbers[1]
            val pulse = allNumbers[2]
            
            // Validate all 3
            if (sys in 70..230 && dia in 40..140 && pulse in 40..160 && sys > dia) {
                processReadingIfValid(sys, dia, pulse)
                return
            }
        }

        // Fallback: If we only see 2 numbers, try to guess if they are Sys/Dia
        if (allNumbers.size >= 2) {
            val n1 = allNumbers[0]
            val n2 = allNumbers[1]
            
            if (n1 > n2 && n1 in 80..230 && n2 in 50..130) {
                processReadingIfValid(n1, n2, 0) // Pulse 0 means unknown
            }
        }
    }

    private fun processReadingIfValid(sys: Int, dia: Int, pulse: Int) {
        runOnUiThread {
            if (isScanning) {
                android.util.Log.i("BPMonitor", "SUCCESS! Found: $sys/$dia P:$pulse")
                handleNewReading(sys, dia, pulse)
                // Auto-stop scanner
                findViewById<Button>(R.id.scanButton).performClick() 
                Toast.makeText(this, "Reading Captured: $sys/$dia", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private var readingListener: ValueEventListener? = null

    private fun startReadingListener(cleanNumber: String) {
        val readingRef = database.child("latest_reading").child(cleanNumber)
        
        // Remove old listener if exists
        stopReadingListener()
        
        readingListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val systolic = snapshot.child("systolic").getValue(Int::class.java)
                val diastolic = snapshot.child("diastolic").getValue(Int::class.java)
                val pulse = snapshot.child("pulse").getValue(Int::class.java) ?: 0
                
                if (systolic != null && diastolic != null) {
                    android.util.Log.d("BPMonitor", "New Reading from RPi: $systolic/$diastolic (P:$pulse)")
                    handleNewReading(systolic, diastolic, pulse)
                }
            }
            override fun onCancelled(error: DatabaseError) {
                android.util.Log.e("BPMonitor", "Reading Listener Error: ${error.message}")
            }
        }
        readingRef.addValueEventListener(readingListener!!)
    }

    private fun stopReadingListener() {
        val sharedPrefs = getSharedPreferences("BPMonitorPrefs", Context.MODE_PRIVATE)
        val myNumber = sharedPrefs.getString("own_number", "") ?: ""
        if (myNumber.isNotBlank() && readingListener != null) {
            database.child("latest_reading").child(cleanNumber(myNumber)).removeEventListener(readingListener!!)
        }
    }

    private fun handleNewReading(systolic: Int, diastolic: Int, pulse: Int) {
        val bpText = findViewById<TextView>(R.id.bpText)
        val pulseText = findViewById<TextView>(R.id.pulseText)
        val statusText = findViewById<TextView>(R.id.statusText)
        val aiInsightText = findViewById<TextView>(R.id.aiInsightText)
        val contactInput = findViewById<EditText>(R.id.contactInput)
        val sharedPrefs = getSharedPreferences("BPMonitorPrefs", Context.MODE_PRIVATE)

        val bpReading = "$systolic over $diastolic"
        val bpDisplay = "$systolic/$diastolic"

        bpText.text = "BP: $bpDisplay"
        pulseText.text = if (pulse > 0) "Pulse: $pulse" else "Pulse: --"

        val status = when {
            systolic < 100 -> "Blood Pressure critically low"
            systolic in 100..109 -> "Blood Pressure is Low"
            systolic >= 131 || diastolic >= 90 -> "Blood Pressure critically high"
            systolic in 121..130 || diastolic in 80..89 -> "Blood Pressure is High"
            systolic in 110..120 -> "Normal Blood Pressure"
            else -> "NORMAL"
        }

        statusText.text = "Status: $status"
        
        // Speak result locally
        val speakMsg = if (pulse > 0) {
            "Your blood pressure is $bpReading. Pulse is $pulse. Status: $status"
        } else {
            "Your blood pressure is $bpReading. Status: $status"
        }
        tts?.speak(speakMsg, TextToSpeech.QUEUE_FLUSH, null, null)

        val contactInputText = contactInput.text.toString()
        val phoneNumbers = contactInputText.split(",").map { it.trim() }.filter { it.isNotBlank() }
        val isEmergency = status.contains("Low") || status.contains("High") || status.contains("critically", ignoreCase = true)

        if (isEmergency && phoneNumbers.isNotEmpty()) {
            val baseMsg = "You are the emergency contact of Jhune! BP Reading: $bpDisplay. Status: $status"
            val myNumber = sharedPrefs.getString("own_number", "") ?: ""

            phoneNumbers.forEach { num ->
                val cleanTarget = cleanNumber(num)
                if (cleanTarget != myNumber) {
                    sendFirebaseAlert(num, baseMsg)
                    sendSms(num, baseMsg)
                }
            }
            showCallDialog(phoneNumbers)
        } else if (!isEmergency) {
            findViewById<TextView>(R.id.lastAlertStatus).text = "Last Alert: None (Normal BP)"
        }

        // AI INSIGHT GENERATION
        if (API_KEY.startsWith("AIza")) {
            aiInsightText.text = "AI Health Assistant is analyzing..."
            lifecycleScope.launch {
                try {
                    val insightPrompt = "The user Jhune just took a blood pressure reading. It is $bpDisplay, pulse is $pulse, which is $status. " +
                            "As a friendly health companion, give him one very short sentence of encouragement or a simple tip. " +
                            "Also, remind him to consult his doctor for any medication or treatment advice. Keep it brief and professional."
                    
                    val insightResponse = generativeModel.generateContent(insightPrompt)
                    val responseText = insightResponse.text
                    
                    if (!responseText.isNullOrBlank()) {
                        aiInsightText.text = "AI Insight: $responseText"
                    }

                    if (isEmergency && phoneNumbers.isNotEmpty()) {
                        val emergencyPrompt = "Jhune's blood pressure is $bpDisplay ($status) and pulse is $pulse. " +
                                "Write a short, urgent message for his emergency contact to check on him. " +
                                "Also include this health tip: $responseText. Keep the whole message under 30 words."
                        
                        val emergencyResponse = generativeModel.generateContent(emergencyPrompt)
                        val customMsgText = emergencyResponse.text ?: "EMERGENCY: Jhune's BP is $bpDisplay ($status). AI Tip: $responseText"
                        
                        val myNumber = sharedPrefs.getString("own_number", "") ?: ""
                        val alertWithSender = if (myNumber.isNotBlank()) "$customMsgText | From: $myNumber" else customMsgText

                        phoneNumbers.forEach { num ->
                            val cleanTarget = cleanNumber(num)
                            if (cleanTarget != myNumber) {
                                sendFirebaseAlert(num, alertWithSender)
                            }
                        }
                    }
                } catch (e: Exception) {
                    aiInsightText.text = "Health Tip: Drink water and rest for 5 minutes."
                }
            }
        }
    }

    private fun startAlertService(number: String) {
        try {
            val serviceIntent = Intent(this, EmergencyAudioService::class.java)
            serviceIntent.putExtra("PHONE_NUMBER", number)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
        } catch (e: Exception) {
            android.util.Log.e("BPMonitor", "Service Start Fail: ${e.message}")
        }
    }

    private fun cleanNumber(raw: String): String {
        // Normalize: remove all non-digits
        var clean = raw.replace(Regex("[^0-9]"), "")
        // If it starts with 0, replace with 63
        if (clean.startsWith("0")) {
            clean = "63" + clean.substring(1)
        }
        // Ensure it's not empty and has a reasonable length for a phone number
        return clean.trim()
    }

    override fun onResume() {
        super.onResume()
        checkFirebaseConnection()
    }

    private fun checkFirebaseConnection() {
        val statusText = findViewById<TextView>(R.id.connectionStatus)
        try {
            val connectedRef = FirebaseDatabase.getInstance(DB_URL).getReference(".info/connected")
            connectedRef.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val connected = snapshot.getValue(Boolean::class.java) ?: false
                    if (connected) {
                        statusText.text = "Connection: ACTIVE"
                        statusText.setTextColor(android.graphics.Color.GREEN)
                        FirebaseDatabase.getInstance(DB_URL).goOnline()
                    } else {
                        statusText.text = "Connection: OFFLINE"
                        statusText.setTextColor(android.graphics.Color.RED)
                    }
                }
                override fun onCancelled(error: DatabaseError) {
                    statusText.text = "Connection Error: ${error.message}"
                }
            })
        } catch (e: Exception) {
            statusText.text = "Init Error: ${e.message}"
        }
    }

    private fun sendFirebaseAlert(targetNumber: String, message: String) {
        val lastAlertText = findViewById<TextView>(R.id.lastAlertStatus)
        val clean = cleanNumber(targetNumber)
        
        if (clean.isNotBlank()) {
            val db = FirebaseDatabase.getInstance(DB_URL).reference
            db.child("alerts").child(clean).setValue(message)
                .addOnSuccessListener {
                    lastAlertText.text = "Last Alert: Sent to $clean"
                    lastAlertText.setTextColor(android.graphics.Color.BLUE)
                    Toast.makeText(this, "Emergency Alert SENT to $clean via Cloud", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener {
                    lastAlertText.text = "Last Alert: FAILED (${it.message})"
                    lastAlertText.setTextColor(android.graphics.Color.RED)
                    Toast.makeText(this, "Cloud Alert FAILED: ${it.message}", Toast.LENGTH_LONG).show()
                }
        }
    }

    private fun showLocalNotification(status: String, bpDisplay: String) {
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Your BP Reading")
            .setContentText("Your BP is $bpDisplay - $status")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)

        with(NotificationManagerCompat.from(this)) {
            if (ActivityCompat.checkSelfPermission(this@MainActivity, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                notify(System.currentTimeMillis().toInt(), builder.build())
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "BP Monitor Alerts"
            val channel = NotificationChannel(CHANNEL_ID, name, NotificationManager.IMPORTANCE_HIGH)
            val notificationManager: NotificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun requestPermissions() {
        val permissions = mutableListOf<String>()
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        
        permissions.add(Manifest.permission.SEND_SMS)
        permissions.add(Manifest.permission.CALL_PHONE)
        permissions.add(Manifest.permission.CAMERA)

        val permissionsToRequest = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (permissionsToRequest.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, permissionsToRequest.toTypedArray(), PERMISSION_REQUEST_CODE)
        }
    }

    private fun showCallDialog(numbers: List<String>) {
        val builder = androidx.appcompat.app.AlertDialog.Builder(this)
        builder.setTitle("Emergency Detected!")
        builder.setMessage("Would you like to call your emergency contact?")
        
        if (numbers.size == 1) {
            builder.setPositiveButton("Call ${numbers[0]}") { _, _ ->
                makePhoneCall(numbers[0])
            }
        } else {
            builder.setPositiveButton("Choose Contact to Call") { _, _ ->
                val items = numbers.toTypedArray()
                androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle("Select Contact")
                    .setItems(items) { _, which ->
                        makePhoneCall(items[which])
                    }
                    .show()
            }
        }
        
        builder.setNegativeButton("Dismiss", null)
        builder.show()
    }

    private fun makePhoneCall(number: String) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            val intent = Intent(Intent.ACTION_CALL)
            intent.data = Uri.parse("tel:$number")
            startActivity(intent)
        } else {
            Toast.makeText(this, "Call Permission Denied!", Toast.LENGTH_SHORT).show()
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CALL_PHONE), PERMISSION_REQUEST_CODE)
        }
    }

    private fun sendSms(phoneNumber: String, message: String) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    this.getSystemService(SmsManager::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    SmsManager.getDefault()
                }
                val uniqueMessage = "$message [ID:${Random.nextInt(1000, 9999)}]"
                val parts = smsManager?.divideMessage(uniqueMessage)
                if (parts != null) {
                    smsManager.sendMultipartTextMessage(phoneNumber, null, parts, null, null)
                    android.util.Log.d("BPMonitor", "SMS Sent to $phoneNumber")
                }
            } catch (e: Exception) {
                android.util.Log.e("BPMonitor", "SMS Fail: ${e.message}")
                Toast.makeText(this, "SMS Failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "SMS Permission DENIED! Cannot send SMS.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale.US
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        cameraExecutor.shutdown()
        super.onDestroy()
    }
}
